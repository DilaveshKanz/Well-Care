from hms import app,db
from hms.models import User
from werkzeug.security import generate_password_hash



with app.app_context():
    db.create_all()

    if not User.query.filter_by(role='Admin').first():
        admin_pass='admin123'
        hashed_pass = generate_password_hash(admin_pass)
        admin_user = User(username = 'admin',email = 'admin@lifehospital.com' , password_hash = hashed_pass , role='Admin')
        
        db.session.add(admin_user)
        db.session.commit()
    
    
if __name__ == "__main__" :
    app.run(debug=True)
