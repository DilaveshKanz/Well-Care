from hms import db
from datetime import datetime
from flask_login import UserMixin

from hms import login_manager
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model,UserMixin):
    id = db.Column(db.Integer,primary_key=True,)
    username = db.Column(db.String(64),unique=True,nullable=False)
    email = db.Column(db.String(128),unique=True,nullable=False)
    password_hash=db.Column(db.String(128))
    age = db.Column(db.Integer,nullable=True)
    phone = db.Column(db.String(16),nullable=True)
    role = db.Column(db.String(16),nullable=False)
    doctor= db.relationship('Doctor' , backref='user',uselist = False)
    patient = db.relationship('Patient' , backref='user')


class Doctor(db.Model):
    id = db.Column(db.Integer , primary_key=True)
    specialization = db.Column(db.String(128),nullable=False)
    user_id = db.Column(db.Integer , db.ForeignKey('user.id'),nullable=False)
    appointments = db.relationship('Appointment',backref='doctor',lazy='select')
    availabilities = db.relationship('DoctorAvailability', backref='doctor', lazy='dynamic')

class DoctorAvailability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)

class Patient(db.Model):
    id = db.Column(db.Integer , primary_key=True)
    phone = db.Column(db.String(16),nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    appointments = db.relationship('Appointment',backref = 'patient' , lazy='select')

class Appointment(db.Model):
    id = db.Column(db.Integer , primary_key=True)
    appointment_date= db.Column(db.DateTime , nullable=False,default = datetime.utcnow)
    status = db.Column(db.String(16),nullable=False,default='Booked')
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'),nullable=False)
    doctor_id = db.Column(db.Integer , db.ForeignKey('doctor.id'),nullable=False)
    treatment = db.relationship('Treatment' , backref='appointment' , uselist=False)

class Treatment(db.Model):
    id = db.Column(db.Integer , primary_key=True)
    diagnosis = db.Column(db.Text , nullable = False)
    prescription = db.Column(db.Text,nullable=True)
    notes = db.Column(db.Text,nullable=True)
    appointment_id = db.Column(db.Integer,db.ForeignKey('appointment.id'),nullable=False)
