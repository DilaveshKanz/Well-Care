from hms import app, db
from hms.models import User, Patient, Doctor, Appointment, Treatment, DoctorAvailability
from flask import render_template,request,redirect,url_for, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask import flash ,session
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import or_
from datetime import datetime, date, timedelta




@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        email = request.form.get('email')
        age = request.form.get('age')
        phone = request.form.get('phone')


        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('register'))
        
        if User.query.filter_by(username=username).first():
            flash('Username already taken' , 'danger') 
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Account already exists with this email' , 'danger')
            return redirect(url_for('register'))
        
        password_hash = generate_password_hash(password)
        new_user = User(username=username , email=email , password_hash=password_hash , age=age , phone=phone , role='Patient')
        db.session.add(new_user)
        db.session.commit()

        new_patient = Patient(phone=phone , user_id=new_user.id)
        db.session.add(new_patient)
        db.session.commit()

        flash('Account Created!' , 'success')
        return redirect(url_for('login'))

        

@app.route('/login' , methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash , password):
            login_user(user)
            flash('Login Successful' , 'success')
            return redirect(url_for('dashboard'))
            
        else:    
            flash('Invalid Credentials' , 'danger')
            return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'Patient':
        return redirect(url_for('patient_dashboard'))

    elif current_user.role == 'Doctor':
        return redirect(url_for('doctor_dashboard'))

    elif current_user.role=='Admin':
        return redirect(url_for('admin_dashboard'))

    else:
        flash('Invalid Role!!!' , 'danger')
        return redirect(url_for('logout'))


@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'Admin':
        flash('Access Denied' , 'danger')
        return redirect(url_for('dashboard'))
    
    doctor_count = Doctor.query.count()
    patient_count = Patient.query.count()
    appointment_count = Appointment.query.count()
    
    
    today = date.today()
    six_months_ago = today - timedelta(days=180)
    
    appointments_last_6_months = db.session.query(
        db.func.strftime('%Y-%m', Appointment.appointment_date),
        db.func.count(Appointment.id)
    ).filter(
        db.func.date(Appointment.appointment_date) >= six_months_ago
    ).group_by(db.func.strftime('%Y-%m', Appointment.appointment_date)).all()
    
    chart_data = { month: count for month, count in appointments_last_6_months }
    
    chart_labels = []
    for i in range(6):
        month = today.month - i
        year = today.year
        if month <= 0:
            month += 12
            year -= 1
        chart_labels.append(date(year, month, 1).strftime('%Y-%m'))
    chart_labels.reverse()
    
    chart_values = [chart_data.get(label, 0) for label in chart_labels]
    
    return render_template('admin_dashboard.html', 
                           doctor_count=doctor_count, 
                           patient_count=patient_count, 
                           appointment_count=appointment_count, 
                           page='dashboard',
                           chart_labels=chart_labels,
                           chart_data=chart_values)

@app.route('/patient/dashboard')
@login_required
def patient_dashboard():
    if current_user.role != 'Patient':
        flash('Access Denied' , 'danger')
        return redirect(url_for('login'))
    
    patient = current_user.patient[0]
    
    total_appointment_count = Appointment.query.filter_by(patient_id=patient.id).count()

    today = date.today()
    seven_days_ago = today - timedelta(days=7)
    recent_appointments = Appointment.query.filter(
        Appointment.patient_id == patient.id,
        db.func.date(Appointment.appointment_date) >= seven_days_ago
    ).order_by(Appointment.appointment_date.desc()).all()
    
    six_months_ago = today - timedelta(days=180)
    
    treatments_last_6_months = db.session.query(
        db.func.strftime('%Y-%m', Appointment.appointment_date),
        db.func.count(Treatment.id)
    ).join(Appointment).filter(
        Appointment.patient_id == patient.id,
        db.func.date(Appointment.appointment_date) >= six_months_ago
    ).group_by(db.func.strftime('%Y-%m', Appointment.appointment_date)).all()
    
    chart_data = { month: count for month, count in treatments_last_6_months }
    
    chart_labels = []
    for i in range(6):
        month = today.month - i
        year = today.year
        if month <= 0:
            month += 12
            year -= 1
        chart_labels.append(date(year, month, 1).strftime('%Y-%m'))
    chart_labels.reverse()
    
    chart_values = [chart_data.get(label, 0) for label in chart_labels]
    
    return render_template('patient_dashboard.html', 
                           appointment_count=total_appointment_count, 
                           recent_appointments=recent_appointments, 
                           page='dashboard',
                           chart_labels=chart_labels,
                           chart_data=chart_values)

@app.route('/doctor/dashboard')
@login_required
def doctor_dashboard():
    if current_user.role != 'Doctor':
        flash('Access Denied' , 'danger')
        return redirect(url_for('dashboard'))
    
    doctor = current_user.doctor
    if not doctor:
        flash('Error','danger')
        return redirect(url_for('logout'))
    treatment_count = Treatment.query.filter(Treatment.appointment.has(doctor_id=doctor.id)).count()
    appointment_count = Appointment.query.filter_by(doctor_id=current_user.doctor.id).count()
    
    today = date.today()
    seven_days_ago = today - timedelta(days=6)
    
    appointments_last_7_days = db.session.query(
        db.func.date(Appointment.appointment_date),
        db.func.count(Appointment.id)
    ).filter(
        Appointment.doctor_id == doctor.id,
        db.func.date(Appointment.appointment_date).between(seven_days_ago, today)
    ).group_by(db.func.date(Appointment.appointment_date)).all()
    
    chart_data = { d: c for d, c in appointments_last_7_days }
    
    chart_labels = [(seven_days_ago + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
    chart_values = [chart_data.get(label, 0) for label in chart_labels]
    
    return render_template('doctor_dashboard.html', 
                           appointment_count=appointment_count,
                           treatment_count=treatment_count, 
                           page='dashboard',
                           chart_labels=chart_labels,
                           chart_data=chart_values)

 
@app.route('/admin/add_doctor', methods=['GET', 'POST'])
@login_required
def add_doctor():
    if current_user.role != 'Admin':
        flash('Access Denied' , 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        specialization = request.form.get('specialization')
        phone = request.form.get('phone')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists' , 'danger') 
            return redirect(url_for('add_doctor'))
        
        if User.query.filter_by(email=email).first():
            flash('Email address is already registered' , 'danger')
            return redirect(url_for('add_doctor'))
        try:
            password_hash = generate_password_hash(password)
            new_user = User(username=username , email=email , password_hash=password_hash , phone=phone , role='Doctor')
            db.session.add(new_user)
            db.session.commit()

            new_doctor = Doctor(specialization=specialization, user_id=new_user.id)
            db.session.add(new_doctor)
            db.session.commit()

            flash(f'Doctor {username} Added Successfully!' , 'success')
            return redirect(url_for('manage_doctors'))
        
        except Exception as e:
            db.session.rollback()
            flash('Error adding doctor: {e}' , 'danger')
            return redirect(url_for('add_doctor'))

    return render_template('add_doctor.html')


@app.route('/admin/manage_doctors')
@login_required
def manage_doctors():
    if current_user.role != 'Admin':
        flash('Access Denied' , 'danger')
        return redirect(url_for('dashboard'))
    

    search_query = request.args.get('search')
    if search_query:
        search_term = f"%{search_query}%"
        search_term = search_term.lower()
        doctors = Doctor.query.join(User).filter(or_(User.username.ilike(search_term),Doctor.specialization.ilike(search_term),User.email.ilike(search_term))).all()
    
    else:
        doctors = Doctor.query.all()
    
    return render_template('manage_doctors.html', doctors=doctors , search_query=search_query, page='manage_doctors')


@app.route('/admin/delete_doctor/<int:doctor_id>', methods=['POST'])
@login_required
def delete_doctor(doctor_id):
    if current_user.role != 'Admin':
        flash('Access Denied' , 'danger')
        return redirect(url_for('login'))
  
    try:
        doctor = Doctor.query.get_or_404(doctor_id)
        user = User.query.get(doctor.user_id)
        db.session.delete(doctor)
        db.session.delete(user)
        db.session.commit()
        flash('Doctor deleted successfully' , 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting doctor: {e}' , 'danger')
    
    return redirect(url_for('manage_doctors'))

@app.route('/admin/update_doctor/<int:doctor_id>', methods=['GET', 'POST'])
@login_required
def update_doctor(doctor_id):
    if current_user.role != 'Admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('dashboard'))

    doctor_to_update = Doctor.query.get_or_404(doctor_id)
    
    if request.method == 'POST':
        new_username = request.form.get('username')
        new_email = request.form.get('email')
        
        existing_user = User.query.filter(User.username == new_username, User.id != doctor_to_update.user_id).first()
        if existing_user:
            flash('That username is already taken by another user.', 'danger')
            return redirect(url_for('update_doctor', doctor_id=doctor_id))

        existing_email = User.query.filter(User.email == new_email, User.id != doctor_to_update.user_id).first()
        if existing_email:
            flash('That email is already registered by another user.', 'danger')
            return redirect(url_for('update_doctor', doctor_id=doctor_id))

        try:
            doctor_to_update.user.username = new_username
            doctor_to_update.user.email = new_email
            doctor_to_update.specialization = request.form.get('specialization')
            
            db.session.commit()
            flash(f'Doctor {new_username} updated successfully!', 'success')
            return redirect(url_for('manage_doctors'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating doctor: {e}', 'danger')
            return redirect(url_for('update_doctor', doctor_id=doctor_id))

    return render_template('update_doctor.html', doctor=doctor_to_update)


@app.route('/doctor/appointment/<int:appointment_id>', methods=['GET', 'POST'])
@login_required
def manage_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    doctor = current_user.doctor

    if appointment.doctor_id != doctor.id:
        flash('This is not your appointment.', 'danger')
        return redirect(url_for('doctor_appointments'))

    treatment = Treatment.query.filter_by(appointment_id=appointment.id).first()

    if request.method == 'POST':
        try:
            appointment.status = request.form.get('status')
            
            diagnosis = request.form.get('diagnosis')
            prescription = request.form.get('prescription')

            if treatment:
                treatment.diagnosis = diagnosis
                treatment.prescription = prescription
            else:
                new_treatment = Treatment(
                    diagnosis=diagnosis,
                    prescription=prescription,
                    appointment_id=appointment.id,
                )
                db.session.add(new_treatment)
            
            db.session.commit()
            flash('Appointment and treatment details saved.', 'success')
            return redirect(url_for('doctor_appointments'))

        except Exception as e:
            db.session.rollback()
            flash(f'Error saving details: {e}', 'danger')

    return render_template('doctor_manage_appointment.html', appointment=appointment, treatment=treatment)



@app.route('/admin/manage_patients')
@login_required
def manage_patients():
    if current_user.role != 'Admin':
        flash('Access Denied.', 'danger')
        return redirect(url_for('dashboard'))
    
    search_query = request.args.get('search')

    if search_query:
        search_term = f"%{search_query}%"
        
        search_id = None
        
        if search_term.isdigit():
            search_id = int(search_term)
        
        else : search_term = search_term.lower()
        patients_list = Patient.query.join(User).filter(or_(User.username.ilike(search_term),User.email.ilike(search_term),Patient.phone.ilike(search_term),Patient.id==search_id)).all()
    
    else:
        patients_list = Patient.query.all()
    
    return render_template('manage_patients.html', patients=patients_list, page='manage_patients')


@app.route('/patient/update_profile', methods=['GET', 'POST'])
@login_required
def patient_update_profile():
    if current_user.role != 'Patient':
        flash('Access Denied', 'danger')
        return redirect(url_for('dashboard'))

    patient = current_user.patient[0]
    user = current_user

    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.age = request.form.get('age')
        patient.phone = request.form.get('phone')

        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('patient_dashboard'))

    return render_template('patient_update_profile.html', user=user, patient=patient, page='patient_update_profile')


@app.route('/patient/book_appointment', methods=['GET', 'POST'])
@login_required
def book_appointment():
    if current_user.role != 'Patient':
        flash('Only patients can book appointments.', 'danger')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        try:
            doctor_id = request.form.get('doctor_id')
            appointment_date_str = request.form.get('appointment_date')
            
            patient = current_user.patient[0]
            appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%dT%H:%M')

            availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor_id).all()
            is_available = False
            for availability in availabilities:
                if availability.start_time <= appointment_date <= availability.end_time:
                    is_available = True
                    break
            
            if not is_available:
                flash('Doctor is not available at the selected time.', 'danger')
                return redirect(url_for('book_appointment'))

            existing_appointment = Appointment.query.filter_by(doctor_id=doctor_id, appointment_date=appointment_date).first()
            if existing_appointment:
                flash('Doctor already has an appointment at the selected time.', 'danger')
                return redirect(url_for('book_appointment'))

            new_appointment = Appointment(
                appointment_date=appointment_date,
                status='Scheduled',
                patient_id=patient.id,
                doctor_id=doctor_id
            )

            db.session.add(new_appointment)
            db.session.commit()

            flash('Appointment booked successfully!', 'success')
            return redirect(url_for('patient_appointments')) 
        
        except Exception as e:
            db.session.rollback()
            flash(f'Error booking appointment: {e}', 'danger')
            return redirect(url_for('book_appointment'))
    
    doctors_list = Doctor.query.join(User).all()
        
    return render_template('book_appointment.html', doctors=doctors_list, page='book_appointment')


@app.route('/patient/appointments')
@login_required
def patient_appointments():

    if current_user.role != 'Patient':
        flash('Only patients can view this page.', 'danger')
        return redirect(url_for('dashboard'))

    patient = current_user.patient[0]

    appointments_list = Appointment.query.filter_by(patient_id=patient.id)\
                                        .order_by(Appointment.appointment_date.desc()).all()
    
    return render_template('patient_appointments.html', appointments=appointments_list, page='patient_appointments')


@app.route('/patient/treatment')
@login_required
def patient_treatment():

    if current_user.role != 'Patient':
        flash('Only patients can view this page.', 'danger')
        return redirect(url_for('dashboard'))


    patient = current_user.patient[0]



    treatment_list = Treatment.query.join(Appointment).filter(Appointment.patient_id == patient.id)\
                                      .order_by(Appointment.appointment_date.desc()).all()
    
    return render_template('patient_treatment.html', treatments=treatment_list, page='patient_treatment')


@app.route('/admin/delete_patient/<int:patient_id>', methods=['POST'])
@login_required
def delete_patient(patient_id):
    if current_user.role != 'Admin':
        flash('Access Denied.' , 'danger')
        return redirect(url_for('dashboard'))
  
    try:
        patient = Patient.query.get_or_404(patient_id)
        user = User.query.get(patient.user_id)
        db.session.delete(patient)
        db.session.delete(user)
        db.session.commit()
        flash('Patient deleted successfully.' , 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting patient: {e}' , 'danger')
    
    return redirect(url_for('manage_patients'))

@app.route('/admin/update_patient/<int:patient_id>', methods=['GET', 'POST'])
@login_required
def update_patient(patient_id):

    if current_user.role != 'Admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('dashboard'))


    patient_to_update = Patient.query.get_or_404(patient_id)
    
    if request.method == 'POST':

        new_username = request.form.get('username')
        new_email = request.form.get('email')
        

        existing_user = User.query.filter(User.username == new_username, User.id != patient_to_update.user_id).first()
        if existing_user:
            flash('That username is already taken by another user.', 'danger')
            return redirect(url_for('update_patient', patient_id=patient_id))

        existing_email = User.query.filter(User.email == new_email, User.id != patient_to_update.user_id).first()
        if existing_email:
            flash('That email is already registered by another user.', 'danger')
            return redirect(url_for('update_patient', patient_id=patient_id))


        try:
            patient_to_update.user.username = new_username
            patient_to_update.user.email = new_email
            patient_to_update.phone = request.form.get('contact_number')
            
            db.session.commit()
            flash(f'Patient {new_username} updated successfully!', 'success')
            return redirect(url_for('manage_patients'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating patient: {e}', 'danger')
            return redirect(url_for('update_patient', patient_id=patient_id))


    return render_template('update_patient.html', patient=patient_to_update)
        
@app.route('/admin/manage_appointments')
@login_required
def manage_appointments():

    if current_user.role != 'Admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('dashboard'))
    
    search_query = request.args.get('search')
    query = Appointment.query

    if search_query:
        search_term = f"%{search_query}%"
        

        matching_users = User.query.filter(User.username.ilike(search_term)).all()
        if matching_users:
            user_ids = [user.id for user in matching_users]


            patient_ids = [p.id for p in Patient.query.filter(Patient.user_id.in_(user_ids)).all()]
            doctor_ids = [d.id for d in Doctor.query.filter(Doctor.user_id.in_(user_ids)).all()]

            query = query.filter(
                or_(
                    Appointment.patient_id.in_(patient_ids),
                    Appointment.doctor_id.in_(doctor_ids)
                )
            )
        else:

            query = query.filter(db.false())


    appointments_list = query.order_by(Appointment.appointment_date.desc()).all()
    
    return render_template('manage_appointments.html', appointments=appointments_list, page='manage_appointments', search_query=search_query)

@app.route('/doctor/appointments')
@login_required
def doctor_appointments ():
    if current_user.role != 'Doctor' :
        flash('Access Denied','danger')
        return redirect(url_for('dashboard'))
    doctor = current_user.doctor
    if not doctor:
        flash("Error","danger")
        return redirect(url_for('logout'))
    
    filter_by = request.args.get('filter')
    query = Appointment.query.filter_by(doctor_id = doctor.id)

    if filter_by == 'today':
        today = date.today()
        query = query.filter(db.func.date(Appointment.appointment_date) == today)
    elif filter_by == 'week':
        today = date.today()
        start_of_week = today - timedelta(days=today.weekday())
        end_of_week = start_of_week + timedelta(days=6)
        query = query.filter(db.func.date(Appointment.appointment_date).between(start_of_week, end_of_week))

    appointment_list = query.order_by(Appointment.appointment_date.desc()).all()
        
    return render_template('doctor_appointments.html', appointments=appointment_list, page='doctor_appointments' )

@app.route('/doctor/patient_history/<int:patient_id>')
@login_required
def doctor_patient_history(patient_id):
    if current_user.role != 'Doctor':
        flash('Access Denied', 'danger')
        return redirect(url_for('dashboard'))

    patient = Patient.query.get_or_404(patient_id)
    treatments = Treatment.query.join(Appointment).filter(Appointment.patient_id == patient.id).order_by(Appointment.appointment_date.desc()).all()

    return render_template('doctor_patient_history.html', patient=patient, treatments=treatments)


@app.route('/doctor/availability', methods=['GET', 'POST'])
@login_required
def doctor_availability():
    if current_user.role != 'Doctor':
        flash('Access Denied', 'danger')
        return redirect(url_for('dashboard'))

    doctor = current_user.doctor
    if not doctor:
        flash('Error', 'danger')
        return redirect(url_for('logout'))

    if request.method == 'POST':
        start_time_str = request.form.get('start_time')
        end_time_str = request.form.get('end_time')

        start_time = datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M')
        end_time = datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M')

        today = datetime.now()
        seven_days_from_now = today + timedelta(days=7)

        if not (today <= start_time <= seven_days_from_now and today <= end_time <= seven_days_from_now):
            flash('Availability can only be set for the next 7 days.', 'danger')
            return redirect(url_for('doctor_availability'))

        if start_time >= end_time:
            flash('Start time must be before end time.', 'danger')
            return redirect(url_for('doctor_availability'))

        new_availability = DoctorAvailability(doctor_id=doctor.id, start_time=start_time, end_time=end_time)
        db.session.add(new_availability)
        db.session.commit()
        flash('Availability added successfully!', 'success')
        return redirect(url_for('doctor_availability'))

    availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor.id).order_by(DoctorAvailability.start_time).all()
    return render_template('doctor_availability.html', availabilities=availabilities, page='doctor_availability')

@app.route('/doctor/availability/delete/<int:availability_id>')
@login_required
def delete_availability(availability_id):
    if current_user.role != 'Doctor':
        flash('Access Denied', 'danger')
        return redirect(url_for('dashboard'))

    availability = DoctorAvailability.query.get_or_404(availability_id)
    if availability.doctor.user_id != current_user.id:
        flash('You do not have permission to delete this availability.', 'danger')
        return redirect(url_for('doctor_availability'))

    db.session.delete(availability)
    db.session.commit()
    flash('Availability deleted successfully!', 'success')
    return redirect(url_for('doctor_availability'))


@app.route('/appointment/cancel/<int:appointment_id>', methods=['POST'])
@login_required
def cancel_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if current_user.id != appointment.patient.user_id and current_user.role != 'Admin':
        flash('You do not have permission to cancel this appointment.', 'danger')
        return redirect(url_for('patient_appointments'))
    
    appointment.status = 'Cancelled'
    db.session.commit()
    flash('Appointment cancelled successfully.', 'success')
    return redirect(url_for('patient_appointments'))

@app.route('/appointment/reschedule/<int:appointment_id>', methods=['GET', 'POST'])
@login_required
def reschedule_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if current_user.id != appointment.patient.user_id:
        flash('You do not have permission to reschedule this appointment.', 'danger')
        return redirect(url_for('patient_appointments'))

    if request.method == 'POST':
        new_date_str = request.form.get('new_date')
        new_date = datetime.strptime(new_date_str, '%Y-%m-%dT%H:%M')


        doctor = appointment.doctor
        availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor.id).all()
        is_available = False
        for availability in availabilities:
            if availability.start_time <= new_date <= availability.end_time:
                is_available = True
                break
        
        if not is_available:
            flash('Doctor is not available at the selected time.', 'danger')
            return redirect(url_for('reschedule_appointment', appointment_id=appointment.id))


        existing_appointment = Appointment.query.filter_by(doctor_id=doctor.id, appointment_date=new_date).first()
        if existing_appointment:
            flash('Doctor already has an appointment at the selected time.', 'danger')
            return redirect(url_for('reschedule_appointment', appointment_id=appointment.id))

        appointment.appointment_date = new_date
        appointment.status = 'Scheduled'
        db.session.commit()
        flash('Appointment rescheduled successfully.', 'success')
        return redirect(url_for('patient_appointments'))

    doctor = appointment.doctor
    availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor.id).all()
    return render_template('reschedule_appointment.html', appointment=appointment, availabilities=availabilities)


@app.route('/api/appointments/<int:appointment_id>', methods=['DELETE'])
@login_required
def delete_appointment_api(appointment_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    appointment = Appointment.query.get_or_404(appointment_id)

    try:
        db.session.delete(appointment)
        db.session.commit()
        return jsonify({'message': 'Appointment deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error deleting appointment: {e}'}), 500

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out' , 'info')
    
    return redirect(url_for('login'))


@app.route('/api/doctors', methods=['GET'])
@login_required
def get_doctors():
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    doctors = Doctor.query.all()
    doctor_list = []
    for doctor in doctors:
        doctor_list.append({
            'id': doctor.id,
            'name': doctor.user.username,
            'specialization': doctor.specialization,
            'email': doctor.user.email,
            'phone': doctor.user.phone
        })
    return jsonify(doctor_list)

@app.route('/api/doctors', methods=['POST'])
@login_required
def create_doctor():
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    specialization = data.get('specialization')
    phone = data.get('phone')

    if not all([username, email, password, specialization]):
        return jsonify({'error': 'Missing required fields'}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400
    
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400

    try:
        password_hash = generate_password_hash(password)
        new_user = User(username=username, email=email, password_hash=password_hash, phone=phone, role='Doctor')
        db.session.add(new_user)
        db.session.commit()

        new_doctor = Doctor(specialization=specialization, user_id=new_user.id)
        db.session.add(new_doctor)
        db.session.commit()

        doctor_data = {
            'id': new_doctor.id,
            'name': new_user.username,
            'specialization': new_doctor.specialization,
            'email': new_user.email,
            'phone': new_user.phone
        }
        return jsonify(doctor_data), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error creating doctor: {e}'}), 500

@app.route('/api/doctors/<int:doctor_id>', methods=['PUT'])
@login_required
def update_doctor_api(doctor_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    doctor_to_update = Doctor.query.get_or_404(doctor_id)
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    new_username = data.get('username')
    new_email = data.get('email')

    if new_username:
        existing_user = User.query.filter(User.username == new_username, User.id != doctor_to_update.user_id).first()
        if existing_user:
            return jsonify({'error': 'Username already taken'}), 400
        doctor_to_update.user.username = new_username

    if new_email:
        existing_email = User.query.filter(User.email == new_email, User.id != doctor_to_update.user_id).first()
        if existing_email:
            return jsonify({'error': 'Email already registered'}), 400
        doctor_to_update.user.email = new_email

    if 'specialization' in data:
        doctor_to_update.specialization = data.get('specialization')
    
    if 'phone' in data:
        doctor_to_update.user.phone = data.get('phone')

    try:
        db.session.commit()
        updated_doctor_data = {
            'id': doctor_to_update.id,
            'name': doctor_to_update.user.username,
            'specialization': doctor_to_update.specialization,
            'email': doctor_to_update.user.email,
            'phone': doctor_to_update.user.phone
        }
        return jsonify(updated_doctor_data)
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error updating doctor: {e}'}), 500

@app.route('/api/doctors/<int:doctor_id>', methods=['GET'])
@login_required
def get_doctor(doctor_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    doctor = Doctor.query.get_or_404(doctor_id)
    doctor_data = {
        'id': doctor.id,
        'name': doctor.user.username,
        'specialization': doctor.specialization,
        'email': doctor.user.email,
        'phone': doctor.user.phone
    }
    return jsonify(doctor_data)

@app.route('/api/doctors/<int:doctor_id>', methods=['DELETE'])
@login_required
def delete_doctor_api(doctor_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    doctor = Doctor.query.get_or_404(doctor_id)
    user = User.query.get(doctor.user_id)

    try:
        db.session.delete(doctor)
        db.session.delete(user)
        db.session.commit()
        return jsonify({'message': 'Doctor deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error deleting doctor: {e}'}), 500

@app.route('/api/patients', methods=['GET'])
@login_required
def get_patients():
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    patients = Patient.query.all()
    patient_list = []
    for patient in patients:
        patient_list.append({
            'id': patient.id,
            'name': patient.user.username,
            'email': patient.user.email,
            'phone': patient.phone,
            'age': patient.user.age
        })
    return jsonify(patient_list)

@app.route('/api/patients', methods=['POST'])
@login_required
def create_patient():
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    phone = data.get('phone')
    age = data.get('age')

    if not all([username, email, password, phone]):
        return jsonify({'error': 'Missing required fields'}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400
    
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400

    try:
        password_hash = generate_password_hash(password)
        new_user = User(username=username, email=email, password_hash=password_hash, phone=phone, age=age, role='Patient')
        db.session.add(new_user)
        db.session.commit()

        new_patient = Patient(phone=phone, user_id=new_user.id)
        db.session.add(new_patient)
        db.session.commit()

        patient_data = {
            'id': new_patient.id,
            'name': new_user.username,
            'email': new_user.email,
            'phone': new_patient.phone,
            'age': new_user.age
        }
        return jsonify(patient_data), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error creating patient: {e}'}), 500

@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
@login_required
def update_patient_api(patient_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    patient_to_update = Patient.query.get_or_404(patient_id)
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    new_username = data.get('username')
    new_email = data.get('email')

    if new_username:
        existing_user = User.query.filter(User.username == new_username, User.id != patient_to_update.user_id).first()
        if existing_user:
            return jsonify({'error': 'Username already taken'}), 400
        patient_to_update.user.username = new_username

    if new_email:
        existing_email = User.query.filter(User.email == new_email, User.id != patient_to_update.user_id).first()
        if existing_email:
            return jsonify({'error': 'Email already registered'}), 400
        patient_to_update.user.email = new_email

    if 'phone' in data:
        patient_to_update.phone = data.get('phone')
    
    if 'age' in data:
        patient_to_update.user.age = data.get('age')

    try:
        db.session.commit()
        updated_patient_data = {
            'id': patient_to_update.id,
            'name': patient_to_update.user.username,
            'email': patient_to_update.user.email,
            'phone': patient_to_update.phone,
            'age': patient_to_update.user.age
        }
        return jsonify(updated_patient_data)
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error updating patient: {e}'}), 500

@app.route('/api/patients/<int:patient_id>', methods=['GET'])
@login_required
def get_patient(patient_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    patient = Patient.query.get_or_404(patient_id)
    patient_data = {
        'id': patient.id,
        'name': patient.user.username,
        'email': patient.user.email,
        'phone': patient.phone,
        'age': patient.user.age
    }
    return jsonify(patient_data)

@app.route('/api/patients/<int:patient_id>', methods=['DELETE'])
@login_required
def delete_patient_api(patient_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403

    patient = Patient.query.get_or_404(patient_id)
    user = User.query.get(patient.user_id)

    try:
        db.session.delete(patient)
        db.session.delete(user)
        db.session.commit()
        return jsonify({'message': 'Patient deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error deleting patient: {e}'}), 500

@app.route('/api/appointments', methods=['GET'])
@login_required
def get_appointments():
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    appointments = Appointment.query.all()
    appointment_list = []
    for appointment in appointments:
        appointment_list.append({
            'id': appointment.id,
            'date': appointment.appointment_date,
            'status': appointment.status,
            'patient_id': appointment.patient_id,
            'doctor_id': appointment.doctor_id
        })
    return jsonify(appointment_list)

@app.route('/api/appointments', methods=['POST'])
@login_required
def create_appointment():
    if current_user.role not in ['Admin', 'Patient']:
        return jsonify({'error': 'Access Denied'}), 403

    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    doctor_id = data.get('doctor_id')
    appointment_date_str = data.get('appointment_date')
    patient_id = data.get('patient_id')

    if not all([doctor_id, appointment_date_str, patient_id]):
        return jsonify({'error': 'Missing required fields'}), 400

    try:
        appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%dT%H:%M:%S')


        availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor_id).all()
        is_available = False
        for availability in availabilities:
            if availability.start_time <= appointment_date <= availability.end_time:
                is_available = True
                break
        
        if not is_available:
            return jsonify({'error': 'Doctor is not available at the selected time'}), 400


        existing_appointment = Appointment.query.filter_by(doctor_id=doctor_id, appointment_date=appointment_date).first()
        if existing_appointment:
            return jsonify({'error': 'Doctor already has an appointment at the selected time'}), 400

        new_appointment = Appointment(
            appointment_date=appointment_date,
            status='Scheduled',
            patient_id=patient_id,
            doctor_id=doctor_id
        )

        db.session.add(new_appointment)
        db.session.commit()

        appointment_data = {
            'id': new_appointment.id,
            'date': new_appointment.appointment_date,
            'status': new_appointment.status,
            'patient_id': new_appointment.patient_id,
            'doctor_id': new_appointment.doctor_id
        }
        return jsonify(appointment_data), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error booking appointment: {e}'}), 500

@app.route('/api/appointments/<int:appointment_id>', methods=['PUT'])
@login_required
def update_appointment_api(appointment_id):
    if current_user.role not in ['Admin', 'Patient']:
        return jsonify({'error': 'Access Denied'}), 403

    appointment_to_update = Appointment.query.get_or_404(appointment_id)
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    if 'appointment_date' in data:
        new_date_str = data.get('appointment_date')
        new_date = datetime.strptime(new_date_str, '%Y-%m-%dT%H:%M:%S')


        doctor = appointment_to_update.doctor
        availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor.id).all()
        is_available = False
        for availability in availabilities:
            if availability.start_time <= new_date <= availability.end_time:
                is_available = True
                break
        
        if not is_available:
            return jsonify({'error': 'Doctor is not available at the selected time'}), 400


        existing_appointment = Appointment.query.filter(
            Appointment.doctor_id == doctor.id,
            Appointment.appointment_date == new_date,
            Appointment.id != appointment_id
        ).first()
        if existing_appointment:
            return jsonify({'error': 'Doctor already has an appointment at the selected time'}), 400

        appointment_to_update.appointment_date = new_date

    if 'status' in data:
        appointment_to_update.status = data.get('status')

    try:
        db.session.commit()
        updated_appointment_data = {
            'id': appointment_to_update.id,
            'date': appointment_to_update.appointment_date,
            'status': appointment_to_update.status,
            'patient_id': appointment_to_update.patient_id,
            'doctor_id': appointment_to_update.doctor_id
        }
        return jsonify(updated_appointment_data)
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Error updating appointment: {e}'}), 500

@app.route('/api/appointments/<int:appointment_id>', methods=['GET'])
@login_required
def get_appointment(appointment_id):
    if current_user.role != 'Admin':
        return jsonify({'error': 'Access Denied'}), 403
    appointment = Appointment.query.get_or_404(appointment_id)
    appointment_data = {
        'id': appointment.id,
        'date': appointment.appointment_date,
        'status': appointment.status,
        'patient_id': appointment.patient_id,
        'doctor_id': appointment.doctor_id
    }
    return jsonify(appointment_data)


@app.route('/doctor/availability/<int:doctor_id>')
@login_required
def get_doctor_availability(doctor_id):
    if current_user.role not in ['Patient', 'Admin']:
        return jsonify({'error': 'Access Denied'}), 403

    availabilities = DoctorAvailability.query.filter_by(doctor_id=doctor_id).all()
    availability_data = []
    for av in availabilities:
        availability_data.append({
            'id': av.id,
            'start_time': av.start_time.isoformat(),
            'end_time': av.end_time.isoformat()
        })
    return jsonify(availability_data)